<?php 
require 'conaa.php';
//header("Content-Type: application/json'; charset=UTF-8");
session_start();



if(isset($_GET['value1'])){
$dev=$_GET['value1'];
$get_emp = $database ->prepare ("SELECT (SELECT val1 FROM trans_val WHERE read1=0 and device_id=$dev) as 'val1',(select val2 FROM trans_val WHERE read2=0 AND device_id=$dev) as 'val2' ,(SELECT val3 FROM trans_val WHERE read3=0 and device_id=$dev) as 'val3',(SELECT val4 FROM trans_val WHERE read4=0 and device_id=$dev) as 'val4' ,(SELECT val5 FROM trans_val WHERE read5=0 and device_id=$dev) as 'val5',(SELECT val6 FROM trans_val WHERE read6=0 and device_id=$dev) as 'val6',(SELECT val7 FROM trans_val WHERE read7=0 and device_id=$dev) as 'val7',(SELECT val8 FROM trans_val WHERE read8=0 and device_id=$dev) as 'val8',(SELECT val9 FROM trans_val WHERE read9=0 and device_id=$dev) as 'val9',(SELECT val10 FROM trans_val WHERE read10=0 and device_id=$dev) as 'val10',(SELECT val11 FROM trans_val WHERE read11=0 and device_id=$dev) as 'val11',(SELECT val12 FROM trans_val WHERE read12=0 and device_id=$dev) as 'val12' from trans_val LIMIT 1;");
$get_emp -> execute();
// $in_val=$database ->prepare("update trans_val set read1=1, read2=1,read3=1,read4=1 where device_id = '$dev';");
// $in_val-> execute();


$val="val1:20";
$jso="{\"val2\":20}";

$get_emp = $get_emp -> fetchAll(PDO::FETCH_ASSOC);
$database = null;

print_r(json_encode($get_emp[0]));

}else{
    $database = null;
    $jso="{\"val2\":20}";
    print_r($jso);
}
?>