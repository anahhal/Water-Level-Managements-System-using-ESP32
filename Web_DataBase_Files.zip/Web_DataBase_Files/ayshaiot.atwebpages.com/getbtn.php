<?php 
require 'conaa.php';
header("Content-Type: application/json'; charset=UTF-8");
session_start();
$data = file_get_contents("php://input");

// هنا تحويل جسون الى اوبجيكت


$data =json_decode($data);
$user_id=$data->col1;

$get_emp = $database ->prepare ("SELECT id as col1, name as col2, board as  col3 ,gpio as col4,	state as col5  FROM Outputs where board='$user_id';");
$get_emp -> execute();
$get_emp = $get_emp -> fetchAll(PDO::FETCH_ASSOC);
$database = null;
print_r(json_encode($get_emp));
?>