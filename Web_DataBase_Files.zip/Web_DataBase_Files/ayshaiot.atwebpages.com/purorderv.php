<?php
session_start();

require '../conaa.php';

$get_emp = $database ->prepare ("SELECT  device_id as col1,device_name  as col2, devices.user_id,users.user_name as col3  FROM devices INNER JOIN users  ON devices.user_id = users.user_id");
$get_emp -> execute();
$get_emp = $get_emp -> fetchAll(PDO::FETCH_ASSOC);
$database = null;
print_r(json_encode($get_emp));
?>