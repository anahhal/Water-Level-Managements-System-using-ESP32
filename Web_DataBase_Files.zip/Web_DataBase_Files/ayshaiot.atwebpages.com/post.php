<?php
/*
  Rui Santos
  Complete project details at https://RandomNerdTutorials.com
  
  Permission is hereby granted, free of charge, to any person obtaining a copy
  of this software and associated documentation files.
  
  The above copyright notice and this permission notice shall be included in all
  copies or substantial portions of the Software.
*/

require 'conaa.php';

// Keep this API Key value to be compatible with the ESP32 code provided in the project page. If you change this value, the ESP32 sketch needs to match




if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $api_key = test_input($_POST["api_key"]);
   
        $value1 = test_input($_POST["value1"]);
        $value2 = test_input($_POST["value2"]);
        $value3 = test_input($_POST["value3"]);
       
        
        // Create connection
      
        // Check connection
        date_default_timezone_set('Asia/Gaza');
        $datenaw = date('Y-m-d');
        $timenaw = date('H:i');
        $insert_val = $database ->prepare("INSERT INTO values_tb (device_id,value1, value2, value3,daten,timen) VALUES ('$api_key','$value1 ', ' $value2 ', ' $value3 ',' $datenaw','$timenaw');");
        $insert_val -> execute();
        
    
    

}


function test_input($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}
$database = null;