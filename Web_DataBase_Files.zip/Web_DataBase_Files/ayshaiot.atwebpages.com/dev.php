<?php 
require 'conaa.php';
header("Content-Type: application/json'; charset=UTF-8");
session_start();
$data = file_get_contents("php://input");

// هنا تحويل جسون الى اوبجيكت


$data =json_decode($data);
$user_id=$data->col1;

$get_emp = $database ->prepare ("SELECT device_id as col1, device_name as col2,devices.user_id as  col3 ,address as col4,value1_name as col5,value2_name as col6,value3_name as col7  FROM devices where devices.user_id='$user_id';");
$get_emp -> execute();
$get_emp = $get_emp -> fetchAll(PDO::FETCH_ASSOC);
$database = null;
print_r(json_encode($get_emp));
?>