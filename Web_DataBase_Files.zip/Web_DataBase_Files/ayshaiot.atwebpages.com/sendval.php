<?php
session_start();
require 'conaa.php';
$data = file_get_contents("php://input");

// هنا تحويل جسون الى اوبجيكت
$data =json_decode($data);
$device_id=$data->col13;
$val1=$data->col1;
if($val1 != ""){
$in_val=$database ->prepare("update trans_val set val1='$val1', read1=0 where device_id = '$device_id';");
$in_val-> execute();
}
$val2=$data->col2;
if($val2!=""){
$in_val=$database ->prepare("update trans_val set val2='$val2',read2=0 where device_id = '$device_id';");
$in_val-> execute();
}
$val3=$data->col3;
if($val3!=""){
$in_val=$database ->prepare("update trans_val set val3='$val3',read3=0 where device_id = '$device_id';");
$in_val-> execute();
}
$val4=$data->col4;
if($val4!=""){
$in_val=$database ->prepare("update trans_val set val4='$val4',read4=0 where device_id = '$device_id';");
$in_val-> execute();
}
$val5=$data->col5;
if($val5!=""){
$in_val=$database ->prepare("update trans_val set val5='$val5',read5=0 where device_id = '$device_id';");
$in_val-> execute();
}
$val6=$data->col6;
if($val6!=""){
$in_val=$database ->prepare("update trans_val set val6='$val6',read6=0 where device_id = '$device_id';");
$in_val-> execute();
}
$val7=$data->col7;
if($val7!=""){
$in_val=$database ->prepare("update trans_val set val7='$val7',read7=0 where device_id = '$device_id';");
$in_val-> execute();
}
$val8=$data->col8;
if($val8!=""){
$in_val=$database ->prepare("update trans_val set val8='$val8',read8=0 where device_id = '$device_id';");
$in_val-> execute();
}
$val9=$data->col9;
if($val9!=""){
$in_val=$database ->prepare("update trans_val set val9='$val9',read8=0 where device_id = '$device_id';");
$in_val-> execute();
}
$val10=$data->col10;
if($val10!=""){
$in_val=$database ->prepare("update trans_val set val10='$val10',read10=0 where device_id = '$device_id';");
$in_val-> execute();
}
$val11=$data->col11;
if($val11!=""){
$in_val=$database ->prepare("update trans_val set val11='$val11',read11=0 where device_id = '$device_id';");
$in_val-> execute();
}
$val12=$data->col12;
if($val12!=""){
$in_val=$database ->prepare("update trans_val set val12='$val12',read12=0 where device_id = '$device_id';");
$in_val-> execute();
}
class Product
{
        public $col1 = 1;
        
}
$massage = new Product;
$database = null;
print_r(json_encode($massage));
?>