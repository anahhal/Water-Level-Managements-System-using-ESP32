<?php
session_start();
require 'conaa.php';
$data = file_get_contents("php://input");

// هنا تحويل جسون الى اوبجيكت
$data =json_decode($data);
$btid=$data->col1;

$in_val=$database ->prepare("DELETE FROM Outputs WHERE id = '$btid';");
$in_val-> execute();

$database = null;

?>