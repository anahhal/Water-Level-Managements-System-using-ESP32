<?php
session_start();
require 'conaa.php';

header("Content-Type: application/json'; charset=UTF-8");

$data = file_get_contents("php://input");

// هنا تحويل جسون الى اوبجيكت
$data =json_decode($data);
// هنا طباعة الاسم من الاوبجيكت
$order_no = $data -> col1;
$get_emp = $database ->prepare ("SELECT value1 as col2, value2 as col3,value3 as col4,timen AS col1 from values_tb where device_id = '$order_no' ORDER BY serial DESC LIMIT 10");
$get_emp -> execute();
$get_emp = $get_emp -> fetchAll(PDO::FETCH_ASSOC);
$database = null;
print_r(json_encode($get_emp));
?>