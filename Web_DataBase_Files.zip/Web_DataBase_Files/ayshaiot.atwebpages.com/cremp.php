<?php
require 'conaa.php';
header("Content-Type: application/json'; charset=UTF-8");
session_start();
 $data = file_get_contents("php://input");

// // هنا تحويل جسون الى اوبجيكت
 $data =json_decode($data);

 $first_name = $data ->col1;
 $second_name = $data  ->col2 ;
 $last_name = $data ->col3 ;
 $valid = $database ->prepare ("select * from users where user_name='$first_name'");
  $valid -> execute();
  foreach($valid As $result){
 
  }
  if($first_name=="" or  $second_name=="" or $last_name == ""){
    class Product
    {
            public $col1 = 3;
            
    }
    $massage = new Product;
    print_r(json_encode($massage));
  }
  else if(isset($result[0])){
 
         
    class Product
    {
            public $col1 = 2;
            
    }
    $massage = new Product;
    $database = null;
    print_r(json_encode($massage));
            
    
    
    
  }else{




    
    
   
    $phone= $data ->col4;
   
    $ust= $data ->col5;
    $insert_emp = $database ->prepare ("insert into users(user_name,password,name,phon,ust_id) values ('$first_name','$second_name','$last_name','$phone','$ust');");
     $insert_emp -> execute();
     
       class Product
       {
               public $col1 = 1;
               
       }
       $massage = new Product;
       print_r(json_encode($massage));
    
  }
 