<?php
error_reporting(0);

ini_set('display_errors', 0);
session_start();
if ( isset( $_SESSION['user_id']) and isset( $_SESSION['ust_id'])){
    if($_SESSION['ust_id']==1){
        echo "<script>location.replace('adwispg.php');</script>";
    }else if($_SESSION['ust_id']==2){
        echo "<script>location.replace('uswispg.php');</script>";
    }
}
else{
 function scanqr(){
    require 'conaa.php';  
if(isset($_POST['send'])) {
    $user_name =$_POST['qrcode'];
    $password = $_POST['code'];
    $selectmenu = $database ->prepare("select user_id,password,ust_id from users where user_name = '$user_name' and password = '$password'  ;");
    $selectmenu ->execute();
    foreach($selectmenu AS $result6) {
    }
    if (is_null($result6[0])) {
        
        echo 'Incorrect Username or Password, try again';
    }
    else {
        
        $_SESSION['user_id']=$result6[0];
        $_SESSION['password']=$result6[1];
        $_SESSION['ust_id']=$result6[2];
        if($result6[2]==1){
        $_SESSION['ad']="500aa#$";
        }if($result6[2]==2){
        $_SESSION['us']="jj99+_";
        }
        $_SESSION['loginn']= true;
        if($_SESSION['ust_id']==1){
            echo "<script>location.replace('adwispg.php');</script>";
        }else{
            echo "<script>location.replace('uswispg.php');</script>";
        }
    }
    
    }
    $database = null;
 }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/sheet.css">
    <title>IOTsensors</title>

</head>
<body id="qrbody" >
    <form method="POST" align="center" id="qrform">
    
        <h2 class="vis_h2">User Name</h2>
       <input type="text" placeholder="user name" name="qrcode" class="vis_inp" id="vis_input1" autofocus >
        <h2 class="vis_h2">Password</h2>
       <input type="password" placeholder="password" name="code" class="vis_inp" id="vis_input2">
      
        <button type="submit" name="send" class="vis_but">دخول</button>
         <label id="vis_lable"><?php scanqr(); ?></label>   
    </form>
    
</body>
</html>