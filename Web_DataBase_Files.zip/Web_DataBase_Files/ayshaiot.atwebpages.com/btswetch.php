<?php
session_start();
require 'conaa.php';
$data = file_get_contents("php://input");

// هنا تحويل جسون الى اوبجيكت
$data =json_decode($data);
$device_id=$data->col2;
$val1=$data->col1;

$in_val=$database ->prepare("update Outputs set state='$val1' where id = '$device_id';");
$in_val-> execute();

$database = null;
class Product
{
        public $col1 = 1;
        
}
$massage = new Product;
print_r(json_encode($massage));
?>