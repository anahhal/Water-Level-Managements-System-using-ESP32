<?php
session_start();

header("Access-Control-Allow-Origin: * "); 
//تحديد طرق وصول ا بي اي
header("Access-Control-Allow-methods: * ");
//هذا الجزء لدعم الللغة العربية و بيانات json
header("Content-Type: application/json'; charset=UTF-8");
//اعطاء المدة التي يتم تخزين البانات فيها مؤقتا
header("Access-Control-Allow-Max-Age: 3600 "); 
//اعطاء المتصفح صلاحيات لتبادل بيانات الاختبار المبدئي دون اخطأ
header("Access-Control-Allow-Headers: * "); 
require 'conaa.php';

$get_emp = $database ->prepare ('SELECT users.user_id as col1,users.user_name  AS col2,users.password as col3,name as col4,phon as col5 FROM users where users.ust_id=2 ;');
//$get_emp = $database ->prepare ('SELECT order_no as col1 ,custmer_name as col2 ,table_no as col3 ,res_no as col4 from order_tb;');

$get_emp -> execute();
$get_emp = $get_emp -> fetchAll(PDO::FETCH_ASSOC);
$database = null;
print_r(json_encode($get_emp));
?>