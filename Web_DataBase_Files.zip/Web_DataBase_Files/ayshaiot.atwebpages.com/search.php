<?php 
require 'conaa.php';
header("Content-Type: application/json'; charset=UTF-8");
session_start();
$data = file_get_contents("php://input");

// هنا تحويل جسون الى اوبجيكت


$data =json_decode($data);
$datefrom=$data->col1;
$dateto=$data->col2;
$timefrom=$data->col3;
$timeto=$data->col4;
$did = $data->col5;
$get_emp = $database ->prepare ("SELECT value1 as col1, value2 as col2,value3 as  col3 ,daten as col4,timen as col5, device_id as col6 FROM values_tb where daten between  '$datefrom' and '$dateto' and timen between '$timefrom' and '$timeto' and device_id = '$did';");
$get_emp -> execute();
$get_emp = $get_emp -> fetchAll(PDO::FETCH_ASSOC);
$database = null;
print_r(json_encode($get_emp));
?>