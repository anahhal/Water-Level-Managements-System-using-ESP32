var aa = '<div id="akno"></div><form class="row g-3"><div class="col-md-6"><label for="input0" class="form-label">User Name</label><input type="text" class="form-control"  id="input0" autofocus></div><div class="col-md-6">    <label for="input1" class="form-label">Password</label>    <input type="password" class="form-control" id="input1"></div>  <div class="col-12">    <label for="input2" class="form-label">Customer Name</label>    <input type="text" class="form-control" id="input2" placeholder="name">  </div>  <div class="col-md-6">    <label for="input3" class="form-label">Customer Phone Number</label>    <input type="text" class="form-control" id="input3" placeholder="05">  </div>   <div class="col-md-6">    <label for="input4" class="form-label">Account Type</label>    <select id="input4" class="form-select"> </select></div><div class="col-12"><button type="button" onclick="sendob(5,' + "'" + 'cremp.php' + "'" + ')" class="btn btn-primary">Create Account</button></div></form>';
var aa2 = '<div id="akno"></div><form class="row g-3"><div class="col-md-6"><label for="input0" class="form-label">Sensor Name</label><input type="text"  class="form-control" id="input0" autofocus></div><div class="col-md-6">    <label for="input1" class="form-label">Sensor Address</label>    <input type="text" class="form-control" id="input1"></div><div class="col-md-6">    <label for="input2" class="form-label">1st Sensor Value Name</label>    <input type="text" class="form-control" id="input2"></div> <div class="col-md-6"><label for="input3" class="form-label">2nd Sensor Value Name</label><input type="text" class="form-control" id="input3"></div> <div class="col-md-6">    <label for="input4" class="form-label">3rd Sensor Value Name</label>    <input type="text" class="form-control" id="input4"></div> <div class="col-md-6">    <label for="input6" class="form-label">User Name</label>    <select id="input5" class="form-select"> </select></div><div class="col-12"><button type="button" class="btn btn-primary" onclick="sendob(6,' + "'" + 'admw.php' + "'" + ')">Create Sensor</button></div></form>';
var aa3 = '<form class="row g-3"><div class="row"> <div class="col-md-3">   <label for="input0" class="form-label">R نصف قطر الاسطوانة</label>  <input type="text" class="form-control"  id="input0" placeholder="cm" autofocus>  </div>   <div class="col-md-3"> <label for="input1" class="form-label">r نصف قطر الفتحة</label><input type="text" class="form-control" id="input1" placeholder="cm">  </div><div class="col-md-3">   <label for="input2" class="form-label">h ارتفاع المخروط</label>  <input type="text" class="form-control" id="input2" placeholder="cm"></div><div class="col-md-3">   <label for="input3" class="form-label">H ارتفاع الاسطوانة</label>   <input type="text" class="form-control" id="input3" placeholder="cm">  </div></div><div class="row"> <div class="col-md-3">  <label for="input4" class="form-label">عدد الخزانات بالاعلى</label>  <input type="text" class="form-control" id="input4" placeholder="عدد الخزانات"> </div><div class="col-md-3"> <label for="input5" class="form-label">عدد الخزانات بالاسفل</label>  <input type="text" class="form-control" id="input5" placeholder="عدد الخزانات"></div><div class="col-md-3"><label for="input6" class="form-label">UP ادنى منسوب مياه</label>  <input type="text" class="form-control" id="input6" placeholder="الحد الادني بالمتر"></div><div class="col-md-3">  <label for="input7" class="form-label">UP اعلى منسوب مياه</label>  <input type="text" class="form-control" id="input7" placeholder="الحد الاعلى بالمتر">  </div><div class="row"><div class="col-md-3"><label for="input8" class="form-label">Value 9</label> <input type="text" class="form-control" id="input8" placeholder="val9"></div>  <div class="col-md-3">  <label for="input9" class="form-label">Value 10</label>  <input type="text" class="form-control" id="input9" placeholder="val10">  </div><div class="col-md-3"><label for="input10" class="form-label">Value 11</label>  <input type="text" class="form-control" id="input10" placeholder="val11"></div><div class="col-md-3">    <label for="input11" class="form-label">الزمن بين القراءات</label>  <input type="text" class="form-control" id="input11" placeholder=" الزمن بالدقيقة "></div></div><input type="hidden" id="input12">  <div class="col-12"><button type="button" onclick="sendob(13,' + "'" + 'sendval.php' + "'" + ')" class="btn btn-primary">Send</button></div></form>';
var val = [];
var nam = "Some Data";
var ty = "bar";
var val2 = [];
var nam2 = "Another Set";
var ty2 = "lain";
var val3 = [];
var nam3 = "valu3";
var ty3 = "bar";
var ch = '<div id="chart"></div><figure class="figure"><progress id="file" value="0.9" max="10" style="height:150px;transform:rotate(270deg);"> 32% </progress>  <figcaption class="figure-caption" id="prog3">منسوب ' + nam + '.</figcaption></figure><figure class="figure"><progress id="file2" value="0.9" max="10" style="height:150px;transform:rotate(270deg);"> 32% </progress> <figcaption class="figure-caption" id="prog4">منسوب ' + nam2 + '.</figcaption></figure><figure class="figure"><progress id="file3" value="0.9" max="10" style="height:150px;transform:rotate(270deg);"> 32% </progress>  <figcaption id="prog5" class="figure-caption">منسوب ' + nam3 + '.</figcaption></figure><hr>'
var tt = '<table class="table table-hover"><thead><tr><th scope="col">#</th><th scope="col">User Name</th><th scope="col">Password</th><th scope="col">Customer Name</th><th>phone</th></tr></thead><tbody id="tin"></tbody></table>';
var dno;
var did;

function aaa(xxx) {
    document.getElementById("conteen").innerHTML = xxx;
    document.getElementById("conteen").style.display = "block";
}

function hi(cas) {
    if (cas == 1) {
        window.portfolioModal1.style.display = "none";
        document.getElementById("itor").innerHTML = "";
        document.getElementById("hedo").innerHTML = "";
    }
    if (cas == 2) {
        window.portfolioModal2.style.display = "none";
        document.getElementById("inval").style.display = 'none';
        document.getElementById("putvalue").innerHTML = '';
    }
    if (cas == 3) { window.portfolioModal3.style.display = "none"; }
    if (cas == 4) { window.portfolioModal4.style.display = "none"; }
}

function bbb(xxx, zzz) {
    document.getElementById("tin3").innerHTML = ch;
    document.getElementById("tin3").innerHTML += '<input type="hidden" id="dvn" value="' + xxx + '"><input type="hidden" id="dvlb" value="' + zzz + '">';
}

function ccc(vvv) {
    document.getElementById("tin32").innerHTML = aa3;
    vi(3);


    document.getElementById("input12").value = vvv;

}

function fff() {
    document.getElementById("conteen").innerHTML = "";
    document.getElementById("conteen").style.display = 'none';
}
var dataa = {
    labels: [],
    datasets: [


    ]
}


function cha(xxx, zzz) {

    val = [];
    val2 = [];
    val3 = [];
    dataa.labels = [];
    dataa.datasets = [];


    let data = { col1: xxx };
    fetch("dorderv.php", {
        method: 'POST',
        body: JSON.stringify(data),
        headers: {
            'content-type': 'application/json'
        }
    }).then(response => response.json()).then(data => {
        data.forEach(element => {
            dataa.labels.unshift(element.col1);
            val.unshift(element.col2);
            val2.unshift(element.col3);
            val3.unshift(element.col4);

        });
        dataa.datasets.push({ name: nam, type: ty, values: val }, { name: nam2, type: ty2, values: val2 }, { name: nam3, values: val3 });

    }).then(any => {
        const chart = new frappe.Chart("#chart", { // or a DOM element,
            // new Chart() in case of ES6 module with above usage
            title: zzz,
            data: dataa,
            type: 'axis-mixed', // or 'bar', 'line', 'scatter', 'pie', 'percentage'
            height: 250,
            colors: ['#7cd6fd', '#743ee2', '#ff00ff']
        });
    })


}

function option(loc, name, a) {
    fetch(loc).then(response => response.json()).then(data => {

        let main = document.getElementById(name);
        main.innerHTML = "";
        data.forEach(element => {

            switch (a) {
                case 1:
                    main.innerHTML += "<option value='" + element.col1 + "'>" + element.col2 + "</option>";
                case 2:
                    let btplace3 = "dev.php";
                    let conpl3 = "tin2";
                    main.innerHTML += '<tr><td>' + element.col1 + '</td><td>' + element.col2 + '</td><td>' + element.col3 + '</td><td>' + element.col4 + '</td><td>' + element.col5 + '</td><td><button type="button" class="btn btn-outline-success" onclick="vi(1);search(-1,' + "'" + btplace3 + "'" + ',' + "'" + conpl3 + "'" + ',' + element.col1 + ',0)">User Sensors</button></td></tr>';
            }
        });
    });
}

function vul(xx) {
    let data = { col1: xx };
    fetch("maxv.php", {
        method: 'POST',
        body: JSON.stringify(data),
        headers: {
            'content-type': 'application/json'
        }
    }).then(response => response.json()).then(data => {

        let main = document.getElementById("file");
        data.forEach(element => {

            document.getElementById("file").value = element.col1;
            document.getElementById("file2").value = element.col2;
            document.getElementById("file3").value = element.col3;

        });
    });
    (' + element.col1 + ');
}
var massag = [];
var massa;

function sender(data, plac, pp) {


    fetch(plac, {
        method: 'POST',
        body: JSON.stringify(data),
        headers: {
            'content-type': 'application/json'
        }
    }).then(response => response.json()).then(data => {
        massa = data.col1;

    }).then(any => {
        if (massa == 1) {
            document.getElementById("akno").innerHTML = '<div class="alert alert-success" style="text-align: center;z-index:999999999999;position:relative;"  role="alert">تمت العملية بنجاح</div>';
            document.getElementById("bdd").addEventListener("click", function() { document.getElementById("akno").innerHTML = ''; });
            window.input0.value = "";
            if (pp > 1) { window.input1.value = "" }
            if (pp > 2) { window.input2.value = "" }
            if (pp > 3) { window.input3.value = "" }
            if (pp > 4 && input4.type != 'hidden') { window.input4.value = "" }         
            if (pp > 5) { window.input5.value = "" }
            if (pp > 6) { window.input6.value = "" }
            if (pp > 7) { window.input7.value = "" }
            if (pp > 8 && input8.type != 'hidden') { window.input8.value = "" }            
            if (pp > 9) { window.input9.value = "" }
            if (pp > 10) { window.input10.value = "" }
            if (pp > 11) { window.input11.value = "" }
            if (pp > 12 && input12.type != 'hidden') { window.input12.value = "" }
            
            
            if (pp > 13) { window.input13.value = "" }
        } else if (massa == 2) {
            document.getElementById("akno").innerHTML = '<div class="alert alert-danger" style="text-align: center;"  role="alert">اسم المستخدم موجود بالفعل استخدم اسم اخر</div>';
            document.getElementById("bdd").addEventListener("click", function() { document.getElementById("akno").innerHTML = ''; });

        } else if (massa == 3) {
            document.getElementById("akno").innerHTML = '<div class="alert alert-danger" style="text-align: center;"  role="alert">الرجاء التأكد من ادخال اسم المستخدم وكلمة المرور</div>';
            document.getElementById("bdd").addEventListener("click", function() { document.getElementById("akno").innerHTML = ''; });

        }
    });

}

function sendob(dd, plac) {

    let mw = { col1: window.input0.value };
    let com = 6;
    if (dd > 1) { mw.col2 = window.input1.value }
    if (dd > 2) { mw.col3 = window.input2.value }
    if (dd > 3) { mw.col4 = window.input3.value }
    if (dd > 4) { mw.col5 = window.input4.value }
    if (dd > 5) { mw.col6 = window.input5.value }
    if (dd > 6) { mw.col7 = window.input6.value }
    if (dd > 7) { mw.col8 = window.input7.value }
    
    if (dd > 8) { mw.col9 = window.input8.value }
    if (dd > 9) { mw.col10 = window.input9.value }
    if (dd > 10) { mw.col11 = window.input10.value }
    if (dd > 11) { mw.col12 = window.input11.value } 
    
    if (dd > 12) { mw.col13 = window.input12.value }
    if (dd > 13) { mw.col14 = window.input13.value }
    let ss = dd;
    sender(mw, plac, ss)
}

function search(seaNum, place, cont, val, val2) {

    //let main=document.getElementById(cont);
    let data = { col00: "test" }
    if (seaNum < 0) { data.col1 = val; }
    if (seaNum < -1) { data.col2 = val2; }
    fetch(place, {
        method: 'POST',
        body: JSON.stringify(data),
        headers: {
            'content-type': 'application/json'
        }
    }).then(response => response.json()).then(data => {
        var main = document.getElementById(cont);
        main.innerHTML = "";

        //  if(cont == 'aaa'){main.innerHTML='<table id="sal" class="a"></table>';var main2=document.getElementById("sal");} 
        //else if (cont == 'itor')
        //{main.innerHTML='<table id="sal2" class="a"></table>'; var main2=document.getElementById("sal2");}
        //else if (cont == 'itt'){main.innerHTML='<table id="sal3" class="a"></table>'; var main2=document.getElementById("sal3");}
        //else {main.innerHTML='<table id="sal4" class="a"></table>'; var main2=document.getElementById("sal4");}

        //main2.innerHTML+=fline;

        data.forEach(element => {

            main.innerHTML += '<tr><td>' + element.col1 + '</td><td>' + element.col2 + '</td><td>' + element.col4 + '</td><td><button type="button" class="btn btn-outline-success"  onclick="nam=' + "'" + element.col5 + "'" + ';did=' + element.col1 + ';nam2=' + "'" + element.col6 + "'" + ';nam3=' + "'" + element.col7 + "'" + ';vi(2);bbb(' + element.col1 + ',' + "'" + element.col2 + "'" + ');cha(' + element.col1 + ',' + "'" + element.col2 + "'" + ');prog3.innerHTML=' + "'" + element.col5 + "'" + ';prog4.innerHTML=' + "'" + element.col6 + "'" + ';prog5.innerHTML=' + "'" + element.col7 + "'" + '; vul(' + element.col1 + ');" ><span class="material-symbols-outlined ic2"> monitoring </span>Sensors Reading</button><button type="button" class="btn btn-outline-success"  onclick="ccc(' + element.col1 + ');"><span class="material-symbols-outlined ic2"> forward_to_inbox </span>Send to ESP</button><button type="button" class="btn btn-outline-success" onclick="vi(4);getbtn(' + element.col1 + ');dno=' + element.col1 + ';" ><span class="material-symbols-outlined ic2"> nest_hello_doorbell </span>Activat</button></td></tr>';




        });
    });

}

function option2(place, inp, val) {


    let data = { col1: val }

    fetch(place, {
        method: 'POST',
        body: JSON.stringify(data),
        headers: {
            'content-type': 'application/json'
        }
    }).then(response => response.json()).then(data => {
        var main = document.getElementById(inp);
        main.innerHTML = "";



        data.forEach(element => {

            main.innerHTML += "<option value='" + element.col1 + "'>" + element.col2 + "</option>";



        });
    });

}

function appe(place) {
    conteen.innerHTML = "";
    let temp, clon;
    temp = document.getElementById(place);
    clon = temp.content.cloneNode(true);
    document.getElementById("conteen").appendChild(clon);
    document.getElementById("conteen").style.display = "block";
}

function getbtn(id) {
    let data = { col1: id }

    fetch("getbtn.php", {
        method: 'POST',
        body: JSON.stringify(data),
        headers: {
            'content-type': 'application/json'
        }
    }).then(response => response.json()).then(data => {
        var main = document.getElementById("tin34");
        main.innerHTML = "<table id='actbt'></table>";
        var main2 = document.getElementById("actbt");
        var pointer = 0;
        data.forEach(element => {
            let stat;
            if (element.col5 == 1) {
                stat = "checked"
            } else {
                stat = ""
            }

            main2.innerHTML += '<tr><td style="width:150px"><div class="form-check form-switch"><input class="form-check-input" type="checkbox" role="switch" id="' + element.col1 + '" style="width:60px;height:30px;" onchange="chang(' + element.col1 + ')" value="' + element.col5 + '" ' + stat + '></td><td style="width:150px"><label class="form-check-label" >' + element.col2 + '</label></td style="width:150px"><td><button type="button" class="btn btn-danger" onclick="delbtn(' + element.col1 + ');getbtn(' + dno + ');"><span class="material-symbols-outlined">delete</span></button></div></td></tr>';
            pointer += 1;


        });
        if (pointer == 0) {
            main.innerHTML += '<div class="alert alert-warning" role="alert" style="width:100%;"><span class="material-symbols-outlined ic2"> error </span>NO THERE ANY BUTTON!</div>'
        }
    });
}

function chang(no) {
    let bt = document.getElementById(no);
    let stat;

    if (bt.value == '0') {
        document.getElementById(no).value = '1';
        stat = 1;
    } else {
        document.getElementById(no).value = '0';
        stat = 0;
    }

    setTimeout(() => {
        console.log("pp")
        sender({ col1: stat, col2: no }, "btswetch.php")
    }, 300);
}

function delbtn(no) {
    data = {
        col1: no
    }
    fetch("delbt.php", {
        method: 'POST',
        body: JSON.stringify(data),
        headers: {
            'content-type': 'application/json'
        }
    })
}

function getvalue() {
    data = {
        col1: document.getElementById("datefrom").value,
        col2: document.getElementById("dateto").value,
        col3: document.getElementById("timefrom").value,
        col4: document.getElementById("timeto").value,
        col5: did
    }
    fetch("search.php", {
        method: 'POST',
        body: JSON.stringify(data),
        headers: {
            'content-type': 'application/json'
        }
    }).then(response => response.json()).then(data => {
        // let x = 0;
        document.getElementById("inval").style.display = '';
        document.getElementById("tehead").innerHTML = '    <tr><th scope="col">#</th><th scope="col">Date</th><th scope="col">Time</th><th scope="col">' + nam + '</th><th scope="col">' + nam2 + '</th><th scope="col">' + nam3 + '</th></tr>';

        var main = document.getElementById("putvalue");
        main.innerHTML = '';
        var pointer = 0;
        data.forEach(element => {

            pointer += 1;
            main.innerHTML += ' <tr><th scope="row">' + pointer + '</th><td>' + element.col4 + '</td><td>' + element.col5 + '</td><td>' + element.col1 + '</td><td>' + element.col2 + '</td><td>' + element.col3 + '</td></tr>';



        });
    }).then(any => {
        document.getElementById("datefrom").value = null
        document.getElementById("dateto").value = null
        document.getElementById("timefrom").value = null
        document.getElementById("timeto").value = null
    })
}