let dno = null;

function option(loc, name, a) {
    fetch(loc).then(response => response.json()).then(data => {

        let main = document.getElementById(name);
        main.innerHTML = "";
        data.forEach(element => {

            switch (a) {
                case 1:
                    main.innerHTML += "<option value='" + element.col1 + "'>" + element.col2 + "</option>";
                case 2:
                    main.innerHTML += '<li><a class="dropdown-item" data-bs-dismiss="offcanvas" onclick="dno=' + element.col1 + ';nam=' + "'" + element.col5 + "'" + ';nam2=' + "'" + element.col6 + "'" + ';nam3=' + "'" + element.col7 + "'" + ';aaa(ch);hhh(' + element.col1 + ',' + "'" + element.col2 + "'" + ');cha(' + "'" + element.col1 + "'" + ',' + "'" + element.col2 + "'" + ');" href=""><span class="material-symbols-outlined ic"> monitor_heart </span>' + element.col2 + '</a></li>';
            }
        });

    });
}
var ch = '<div id="chart"></div>'

function aaa(xxx) {
    document.getElementById("conteen2").innerHTML = xxx;
    document.getElementById("conteen2").style.display = "block";
    document.getElementById("conteen2").innerHTML += '<hr><p><a class="btn btn-primary sha" data-bs-toggle="collapse" href="#collapseExample" role="button" aria-expanded="false" aria-controls="collapseExample"><span class="material-symbols-outlined"> search </span><span class="material-symbols-outlined"> arrow_drop_down </span></a></p><br><br><div class="collapse" id="collapseExample" style="overflow:auto;"><div class="card card-body"><div class="row"><div class="col">From :<input type="date" class="form-control" id="datefrom" aria-label="First name"></div><div class="col">To :<input type="date" class="form-control" id="dateto" aria-label="Last name"></div></div><div class="row" ><div class="col">From :<input type="time" class="form-control" id="timefrom" aria-label="First name"></div><div class="col">To :<input type="time" class="form-control" id="timeto" aria-label="Last name"></div></div><br><div class="d-grid gap-2"><button class="btn btn-primary" type="button" onclick="getvalue();">search</button></div><br><hr><table class="table table-bordered" style="display:none;" id="inval"><thead id="tehead"></thead><tbody id="putvalue"></tbody></table></div></div><hr><div class="btn-group" role="group" aria-label="Basic outlined example"><button class="btn btn-outline-warning"  data-dismiss="modal" type="button" onclick="cha(dvn.value,dvlb.value);"><i class="fa fa-times"></i><span>&nbsp;<span class="material-symbols-outlined ic2">autorenew</span>REFRESH</button><button class="btn btn-outline-warning" data-dismiss="modal" type="button" onclick="vi(2);getbtn(dno,\'tin3\')"><i class="fa fa-times"></i><span>&nbsp;<span class="material-symbols-outlined ic2"> nest_hello_doorbell </span>Activate</span></button></div>';
}

function bbb() {

    document.getElementById("conteen2").style.display = "none";
}

function hhh(xxx, zzz) {

    document.getElementById("conteen2").innerHTML += '<input type="hidden" id="dvn" value="' + xxx + '"><input type="hidden" id="dvlb" value="' + zzz + '">';
}
var dataa = {
    labels: [],
    datasets: [


    ]
}
var val = [];
var nam = "Some Data";
var ty = "bar";
var val2 = [];
var nam2 = "Another Set";
var ty2 = "lain";
var val3 = [];
var nam3 = "valu3";
var ty3 = "bar";

function cha(xxx, zzz) {

    val = [];
    val2 = [];
    val3 = [];
    dataa.labels = [];
    dataa.datasets = [];


    let data = { col1: xxx };
    fetch("dorderv.php", {
        method: 'POST',
        body: JSON.stringify(data),
        headers: {
            'content-type': 'application/json'
        }
    }).then(response => response.json()).then(data => {
        data.forEach(element => {
            dataa.labels.unshift(element.col1);
            val.unshift(element.col2);
            val2.unshift(element.col3);
            val3.unshift(element.col4);

        });
        dataa.datasets.push({ name: nam, type: ty, values: val }, { name: nam2, type: ty2, values: val2 }, { name: nam3, values: val3 });

    }).then(any => {
        const chart = new frappe.Chart("#chart", { // or a DOM element,
            // new Chart() in case of ES6 module with above usage
            title: zzz,
            data: dataa,
            type: 'axis-mixed', // or 'bar', 'line', 'scatter', 'pie', 'percentage'
            height: 250,
            colors: ['#7cd6fd', '#743ee2', '#ff00ff']
        });
    })


}

function vi(cas) {
    if (cas == 1) {
        window.portfolioModal1.style.display = "block";
        window.portfolioModal1.style.overflow = "scroll";
    }
    if (cas == 2) {
        window.portfolioModal2.style.display = "block";
        window.portfolioModal2.style.overflow = "scroll";
    }
}
option("mwv.php", "ul11", 2);


function getbtn(id) {
    let data = { col1: id }

    fetch("getbtn.php", {
        method: 'POST',
        body: JSON.stringify(data),
        headers: {
            'content-type': 'application/json'
        }
    }).then(response => response.json()).then(data => {
        var main = document.getElementById("tin3");
        main.innerHTML = "";
        let pointer = 0;
        data.forEach(element => {
            let stat;
            if (element.col5 == 1) {
                stat = "checked"
            } else {
                stat = ""
            }

            main.innerHTML += '<div class="form-check form-switch"><input class="form-check-input" type="checkbox" style="width:60px;height:30px;" role="switch" id="' + element.col1 + '" onchange="chang(' + element.col1 + ')" value="' + element.col5 + '" ' + stat + '><label class="form-check-label" >' + element.col2 + '</label></div><br>';
            pointer += 1;


        });
        if (pointer == 0) {
            main.innerHTML += '<div class="alert alert-warning" role="alert" style="width:100%;"><span class="material-symbols-outlined ic2"> error </span>NO THERE ANY BUTTON!</div>'
        }
    });
}

function chang(no) {
    let bt = document.getElementById(no);
    let stat;

    if (bt.value == '0') {
        document.getElementById(no).value = '1';
        stat = 1;
    } else {
        document.getElementById(no).value = '0';
        stat = 0;
    }

    setTimeout(() => {
        console.log("pp")
        sender({ col1: stat, col2: no }, "btswetch.php")
    }, 300);
}

function sender(data, plac, pp) {


    fetch(plac, {
        method: 'POST',
        body: JSON.stringify(data),
        headers: {
            'content-type': 'application/json'
        }
    }).then(response => response.json()).then(data => {
        massa = data.col1;

    })

}

function sendob(dd, plac) {

    let mw = { col1: window.input0.value };
    let com = 6;
    if (dd > 1) { mw.col2 = window.input1.value }
    if (dd > 2) { mw.col3 = window.input2.value }
    if (dd > 3) { mw.col4 = window.input3.value }
    if (dd > 4) { mw.col5 = window.input4.value }
    if (dd > 5) { mw.col6 = window.input5.value }
    if (dd > 6) { mw.col7 = window.input6.value }
    if (dd > 7) { mw.col8 = window.input7.value }
    if (dd > 8) { mw.col9 = window.input8.value }
    if (dd > 9) { mw.col10 = window.input9.value }
    let ss = dd;
    sender(mw, plac, ss)
}

function hi(cas) {
    if (cas == 1) {
        window.portfolioModal1.style.display = "none";
        document.getElementById("itor").innerHTML = "";
        document.getElementById("hedo").innerHTML = "";
    }
    if (cas == 2) { window.portfolioModal2.style.display = "none"; }
}

function getvalue() {
    data = {
        col1: document.getElementById("datefrom").value,
        col2: document.getElementById("dateto").value,
        col3: document.getElementById("timefrom").value,
        col4: document.getElementById("timeto").value,
        col5: dno
    }
    fetch("search.php", {
        method: 'POST',
        body: JSON.stringify(data),
        headers: {
            'content-type': 'application/json'
        }
    }).then(response => response.json()).then(data => {
        // let x = 0;
        document.getElementById("inval").style.display = '';
        document.getElementById("tehead").innerHTML = '    <tr><th scope="col">#</th><th scope="col">Date</th><th scope="col">Time</th><th scope="col">' + nam + '</th><th scope="col">' + nam2 + '</th><th scope="col">' + nam3 + '</th></tr>';

        var main = document.getElementById("putvalue");
        main.innerHTML = '';
        var pointer = 0;
        data.forEach(element => {

            pointer += 1;
            main.innerHTML += ' <tr><th scope="row">' + pointer + '</th><td>' + element.col4 + '</td><td>' + element.col5 + '</td><td>' + element.col1 + '</td><td>' + element.col2 + '</td><td>' + element.col3 + '</td></tr>';



        });
    }).then(any => {
        document.getElementById("datefrom").value = null
        document.getElementById("dateto").value = null
        document.getElementById("timefrom").value = null
        document.getElementById("timeto").value = null
    })
}