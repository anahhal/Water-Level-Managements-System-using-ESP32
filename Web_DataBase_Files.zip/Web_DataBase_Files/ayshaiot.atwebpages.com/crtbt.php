<?php
require 'conaa.php';
header("Content-Type: application/json'; charset=UTF-8");
session_start();
$data = file_get_contents("php://input");

// هنا تحويل جسون الى اوبجيكت
$data =json_decode($data);
$user= $data ->col1;
$board = $data ->col2;
$name = $data  ->col3 ;
$gpio = $data ->col4 ;
$state= $data ->col5;


$insert_emp = $database ->prepare ("insert into Outputs(name,board,gpio,state) values ('$name','$board','$gpio','$state');");
 $insert_emp -> execute();

 class Product
 {
         public $col1 = 1;
         
 }
 $massage = new Product;
 $database = null;
 print_r(json_encode($massage));
?>