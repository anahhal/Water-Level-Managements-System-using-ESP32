<?php

require 'conaa.php';


$get_emp = $database ->prepare ('select ust_id as col1,ust_name as col2  from ust ;');
$get_emp -> execute();
$get_emp = $get_emp -> fetchAll(PDO::FETCH_ASSOC);
$database = null;
print_r(json_encode($get_emp));
?>