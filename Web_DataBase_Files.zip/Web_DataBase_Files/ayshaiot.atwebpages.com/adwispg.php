<?php
session_start();
// if($_SERVER['SERVER_PORT'] !== 443 &&
//    (empty($_SERVER['HTTPS']) || $_SERVER['HTTPS'] === 'off')) {
//   header('Location: https://' . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI']);
//   exit;
// }
if(isset( $_SESSION['user_id']) and $_SESSION['ust_id']==1 and isset( $_SESSION['password']) and $_SESSION['loginn']== true and $_SESSION['ad']=="500aa#$"){

}else{
  echo "<script>location.replace('index.php');</script>";
}
if(isset($_POST['session_off'])){
  unset($_SESSION['ust_id']);
  unset($_SESSION['user_id']) ;
  unset($_SESSION['password'] ) ;
  echo "<script>location.replace('index.php');</script>";
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@48,400,0,0" />
    <link rel="stylesheet" type="text/css" href="esp-style.css">
    <link href="css/style.css" rel="stylesheet" >
    <title>IOTsensors</title>
    <script src="https://cdn.jsdelivr.net/npm/frappe-charts@1.2.4/dist/frappe-charts.min.iife.js"></script>
    <style>
      .siz{
        height: 25px;
     
      }
    :root {
      --bs-form-check-input-width: 8em;
      --bs-form-check-min-height:  0em;
    }

    </style>
  </head >
<body id="bdd">
    <nav class="navbar navbar-dark bg-dark fixed-top">
        <div class="container-fluid">
          
          <button class="navbar-toggler" type="button" data-bs-toggle="offcanvas" data-bs-target="#offcanvasNavbar" aria-controls="offcanvasNavbar">
            <span class="navbar-toggler-icon"></span>
          </button>
          <a class="navbar-brand" href="#"><span class="material-symbols-outlined ic"> settings_input_antenna </span>IOTsensors</a>
          <div class="offcanvas bg-dark  offcanvas-start" tabindex="-1" id="offcanvasNavbar" aria-labelledby="offcanvasNavbarLabel">
            <div class="offcanvas-header">
              <h5 class="offcanvas-title text-light" id="offcanvasNavbarLabel">IOTsensors</h5>
              <button type="button" class="btn-close btn-close-white  text-reset" data-bs-dismiss="offcanvas" aria-label="Close"></button>
            </div>
            <div class="offcanvas-body">
              <ul class="navbar-nav justify-content-end flex-grow-1 pe-3">
                
                <li class="nav-item">
                  <a class="nav-link active text-light link-close ll men" data-bs-dismiss="offcanvas" aria-current="page" onclick="fff();" href=""><span class="material-symbols-outlined ic">home</span>Home Page</a>
                </li>

                <li class="nav-item">
                    <a class="nav-link  text-light link-close ll men" data-bs-dismiss="offcanvas" onclick="aaa(tt);option('data.php','tin',2);" ><span class="material-symbols-outlined ic">nest_remote_comfort_sensor</span>Sensors & Sensors Reading</a>
                  </li>
                  
                  <li class="nav-item">
                    <a class="nav-link  text-light link-close ll men" data-bs-dismiss="offcanvas" aria-current="page"  onclick="appe('btpage');option('data.php','input0',1);"><span class="material-symbols-outlined ic">switch_access_shortcut_add</span>Create Output  </a>
                  </li>
                  
                  
                <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle text-light men"  href="" id="offcanvasNavbarDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                <span class="material-symbols-outlined ic">add_box</span> Accounts and Sensors
                  </a>
                  <ul class="dropdown-menu dropdown-menu-dark" aria-labelledby="offcanvasNavbarDropdown">
                    <li><a class="dropdown-item text link-close ll" data-bs-dismiss="offcanvas" onclick="aaa(aa);option('pp.php','input4',1);setTimeout(function() {document.getElementById('input0').focus();},350);" href=""><span class="material-symbols-outlined ic">person_add</span>Create account</a></li>
                    <li><a class="dropdown-item text link-close ll" data-bs-dismiss="offcanvas" onclick="aaa(aa2);option('data.php','input5',1);setTimeout(function() {document.getElementById('input0').focus();},350); " href=""><span class="material-symbols-outlined ic"> control_point_duplicate </span>Create sensor</a></li>
                    <li>
 

                    
                      <hr class="dropdown-divider text">
                    </li>
                  </ul>
                </li>
                <li class="nav-item">
                  <form method="POST">
                  <button class="btn btn-secondary " type="submit" name="session_off" aria-current="page"  href="">Log out</button>
                  </form>
                </li>
              </ul>
              
            </div>
          </div>
        </div>
      </nav>
<div style="margin-top: 50px;" id="altt77"></div>
<div id="conteen"  style="overflow-x:scroll;" class="conteen"></div>
<div class="modal  text-center portfolio-modal" style="background: rgba(82, 82, 82, 0.7);" role="dialog" tabindex="-1" id="portfolioModal1"><div class="modal-dialog modal-lg" role="document"><div class="modal-content" style="border-color:#d98700;border-style:double;border-width: 8px;" ><div class="container"><div class="row"><button type="button" class="btn-close" aria-label="Close" onclick="hi(1);"></button><div class="modal-body"><h2 class="text-uppercase">User Devices</h2><hr><table class="a" id="hedo"></table><div class="a" id="itor"></div><table class="table table-hover"><thead><tr><th scope="col">#</th><th scope="col">name</th><th scope="col">address</th></tr></thead><tbody id="tin2"><tr><th scope="row">1</th><td>Mark</td><td>Otto</td><td>@mdo</td></tr><tr><th scope="row">2</th><td>Jacob</td><td>Thornton</td><td>@fat</td></tr><tr><th scope="row">3</th><td colspan="2">Larry the Bird</td><td>@twitter</td></tr></tbody></table></div></div></div></div></div></div>
<div class="modal  text-center portfolio-modal" style="background: rgba(82, 82, 82, 0.7);" role="dialog"  tabindex="-1" id="portfolioModal2"><div class="modal-dialog modal-lg" role="document"><div class="modal-content"  style="border-color:#001f9f;border-style:double;border-width: 8px;" ><div class="container"><div class="row"><button type="button" class="btn-close" aria-label="Close" onclick="hi(2);"></button><button type="button"  class="btn"  style="float:left;width:10px;height:20px;" onclick="cha(dvn.value,dvlb.value);vul(dvn.value);"><span class="material-symbols-outlined" style="font-size: 24px;margin: -100px;padding: 0px;">autorenew</span></button><div class="modal-body"><h2 class="text-uppercase">Sensor Reading</h2><hr><dev id="tin3"></dev><p><a class="btn btn-primary sha" data-bs-toggle="collapse" href="#collapseExample" role="button" aria-expanded="false" aria-controls="collapseExample"><span class="material-symbols-outlined"> search </span><span class="material-symbols-outlined"> arrow_drop_down </span></a></p><br><br><div class="collapse" id="collapseExample" style="overflow:auto;"><div class="card card-body">
<div class="row"><div class="col">From :<input type="date" class="form-control" id="datefrom" aria-label="First name"></div><div class="col">To :<input type="date" class="form-control" id="dateto" aria-label="Last name"></div></div>
<div class="row" ><div class="col">From :<input type="time" class="form-control" id="timefrom" aria-label="First name"></div><div class="col">To :<input type="time" class="form-control" id="timeto" aria-label="Last name"></div></div>
<br>
<div class="d-grid gap-2">
  <button class="btn btn-primary" type="button" onclick="getvalue();">search</button>

</div>
<br><hr>
<table class="table table-bordered" style="display:none;" id="inval">
<thead id="tehead">

  </thead>
  <tbody id="putvalue">
   
   
  </tbody>
</table>
</div></div><hr></div></div></div></div></div></div>
<div class="modal  text-center portfolio-modal" style="background: rgba(82, 82, 82, 0.7);" role="dialog" tabindex="-1" id="portfolioModal3"><div class="modal-dialog modal-lg" role="document"><div class="modal-content" style="border-color:#001f9f;border-style:double;border-width: 8px;" ><div class="container"><div class="row"><button type="button" class="btn-close" aria-label="Close" onclick="hi(3);"></button><div class="modal-body"><h2 class="text-uppercase">send to ESP</h2><hr><div id="akno"></div><dev id="tin32"></dev><hr></div></div></div></div></div></div>
<div class="modal  text-center portfolio-modal"  style="background: rgba(82, 82, 82, 0.7);" role="dialog" tabindex="-1" id="portfolioModal4"><div class="modal-dialog modal-lg" role="document"><div class="modal-content" style="border-color:#001f9f;border-style:double;border-width: 8px;" ><div class="container"><div class="row"><button type="button" class="btn-close" aria-label="Close" onclick="hi(4);"></button><div class="modal-body"><h2 class="text-uppercase">Activat button</h2><hr><div id="akno"></div><dev id="tin34"></dev><hr></div></div></div></div></div></div>
</body>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.10.2/dist/umd/popper.min.js" integrity="sha384-7+zCNj/IqJ95wo16oMtfsKbZ9ccEh31eOz1HGyDuCQ6wgnyJNSYdrPa03rtR1zdB" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.min.js" integrity="sha384-QJHtvGhmr9XOIpI6YVutG+2QOK9T+ZnN4kzFN1RtK3zEFEIsxhlmWl5/YESvpZ13" crossorigin="anonymous"></script>
<script src="js/main.js" ></script>
<script>
  function vi(cas){
     if (cas == 1){window.portfolioModal1.style.display="block";window.portfolioModal1.style.overflow="scroll";}
     if (cas == 2){window.portfolioModal2.style.display="block";window.portfolioModal2.style.overflow="scroll"; }
     if (cas == 3){window.portfolioModal3.style.display="block";window.portfolioModal3.style.overflow="scroll"; }
     if (cas == 4){window.portfolioModal4.style.display="block";window.portfolioModal4.style.overflow="scroll"; }
}
</script>
<template id="btpage">
<section>
<div class="ddiv"><form onsubmit="return createOutput();">
        <h3>Create New Output</h3>
        <div id="akno"></div>
        <hr>
        <label for="input0">User</label>
        <select  name="user" id="input0" oninput="option2('dev.php','input1',user.value)"></select><br>
        <label for="input1">Board ID</label>
        <select  name="board"  id="input1"></select>
        <label for="input2">Name</label>
        <input type="text" name="name" id="input2"><br>
        <label for="input3">GPIO Number</label>
        <input type="number" name="gpio" min="0" id="input3">
        <label for="input4">Initial GPIO State</label>
        <select id="input4" name="state">
          <option value="0">0 = OFF</option>
          <option value="1">1 = ON</option>
        </select>
        <div class="d-grid gap-2">
        <button type="button" class="btn btn-primary"  onclick="sendob(5,'crtbt.php')">Create Output</button>
        </div>
        <p><strong>Note:</strong> in some devices, you might need to refresh the page to see your newly created buttons or to remove deleted buttons.</p>
    </form></div>
</section>
</template>
</html>
