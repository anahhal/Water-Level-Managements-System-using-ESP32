<?php
$username = "4062895_aysha";
$password = "asdfg@12345";
$database = new PDO("mysql:host=fdb33.awardspace.net;dbname=4062895_aysha;charset=utf8",$username,$password);
?>