<?php
session_start();
if(isset( $_SESSION['user_id']) and $_SESSION['ust_id']==2 and isset( $_SESSION['password']) and $_SESSION['loginn']== true and $_SESSION['us']="jj99+_"){

}else{
  echo "<script>location.replace('index.php');</script>";
}
if(isset($_POST['session_off'])){
  unset($_SESSION['ust_id']);
  unset($_SESSION['user_id']) ;
  unset($_SESSION['password'] ) ;
  echo "<script>location.replace('index.php');</script>";
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@48,400,0,0" />
    <link href="css/style.css" rel="stylesheet" >
    <title>IOTsensors</title>
    <script src="https://cdn.jsdelivr.net/npm/frappe-charts@1.2.4/dist/frappe-charts.min.iife.js"></script>
</head>
<body>
    <nav class="navbar navbar-dark bg-dark fixed-top">
        <div class="container-fluid">
          <a class="navbar-brand" href="#"><span class="material-symbols-outlined ic"> settings_input_antenna </span>IOTsensors</a>
          <button class="navbar-toggler" type="button" data-bs-toggle="offcanvas" data-bs-target="#offcanvasNavbar" aria-controls="offcanvasNavbar">
            <span class="navbar-toggler-icon"></span>
          </button>
          <div class="offcanvas bg-dark offcanvas-end" tabindex="-1" id="offcanvasNavbar" aria-labelledby="offcanvasNavbarLabel">
            <div class="offcanvas-header">
              <h5 class="offcanvas-title" id="offcanvasNavbarLabel">قائمة الاجهزة</h5>
              <button type="button" class="btn-close btn-close-white  text-reset" data-bs-dismiss="offcanvas" aria-label="Close"></button>
            </div>
            <div class="offcanvas-body">
              <ul class="navbar-nav dropdown-menu-dark justify-content-end flex-grow-1 pe-3" id="ul11">
                <li class="nav-item">
                  <a class="nav-link active text-light link-close ll" data-bs-dismiss="offcanvas" aria-current="page" onclick="bbb();" href="">الصفحة الرئيسية</a>
                </li>
                <li><a class="dropdown-item text-light link-close ll" data-bs-dismiss="offcanvas" onclick="aaa(ch);cha();" href="">مجس 1</a></li>
                    <li><a class="dropdown-item text-light link-close ll" data-bs-dismiss="offcanvas" onclick="aaa(ch);cha();" href="">مجس2</a></li>
                </ul> 
                <ul class="navbar-nav justify-content-end flex-grow-1 pe-3" >  
                    <li>
                      <hr class="dropdown-divider text-light">
                    </li>
                <li class="nav-item">
                  <form method="POST">
                  <button class="btn btn-secondary " type="submit" name="session_off"    href="">تسجيل خروج</button>
                  </form>
                </li>
               
              
            </div>
          </div>
        </div>
      </nav>
<div id="conteen2" class="conteen"></div>
<div class="modal  text-center portfolio-modal"  style="background: rgba(82, 82, 82, 0.7);" role="dialog" tabindex="-1" id="portfolioModal2"><div class="modal-dialog modal-lg" role="document"><div class="modal-content" style="border-color:#001f9f;border-style:double;border-width: 8px;" ><div class="container"><div class="row"><button type="button" class="btn-close" aria-label="Close" onclick="hi(2);"></button><div class="modal-body"><h2 class="text-uppercase">Activat button</h2><hr><div id="akno"></div><dev id="tin3"></dev><hr></div></div></div></div></div></div>
</body>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.10.2/dist/umd/popper.min.js" integrity="sha384-7+zCNj/IqJ95wo16oMtfsKbZ9ccEh31eOz1HGyDuCQ6wgnyJNSYdrPa03rtR1zdB" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.min.js" integrity="sha384-QJHtvGhmr9XOIpI6YVutG+2QOK9T+ZnN4kzFN1RtK3zEFEIsxhlmWl5/YESvpZ13" crossorigin="anonymous"></script>
<script src="js/main2.js" ></script>

</html>