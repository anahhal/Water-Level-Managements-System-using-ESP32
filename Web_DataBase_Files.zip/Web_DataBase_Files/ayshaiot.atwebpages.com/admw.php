<?php
require 'conaa.php';
header("Content-Type: application/json'; charset=UTF-8");
session_start();
$data = file_get_contents("php://input");

// هنا تحويل جسون الى اوبجيكت
$data =json_decode($data);




$device_name = $data ->col1;
$address = $data  ->col2 ;

$val1 = $data ->col3 ;
$val2= $data ->col4;
$val3= $data ->col5;
$user_id=$data->col6;



$insert_emp = $database ->prepare ("insert into devices(device_name,user_id,address,value1_name,value2_name,value3_name) values ('$device_name','$user_id','$address','$val1','$val2','$val3');");
 $insert_emp -> execute();
 $find_id= $database -> prepare("select device_id from devices where user_id='$user_id' and device_name='$device_name' ORDER BY device_id DESC LIMIT 1;");
 $find_id -> execute();
 foreach($find_id as $res){
 }
 $crtrans=$database ->prepare("insert into trans_val(device_id,read1,read2,read3,read4,read5,read6,read7,read8) values ('$res[0]',1,1,1,1,1,1,1,1)");
 $crtrans -> execute();
 class Product
 {
         public $col1 = 1;
         
 }
 $massage = new Product;
 $database = null;
 print_r(json_encode($massage));
?>
