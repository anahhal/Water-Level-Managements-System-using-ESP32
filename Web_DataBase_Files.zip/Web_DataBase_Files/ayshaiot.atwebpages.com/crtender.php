<?php
require '../conaa.php';
header("Content-Type: application/json'; charset=UTF-8");
session_start();
$data = file_get_contents("php://input");

// هنا تحويل جسون الى اوبجيكت
$data =json_decode($data);
// هنا طباعة الاسم من الاوبجيكت
date_default_timezone_set('Asia/Gaza');
 $timenaw = date('H:i');
 $datenaw = date('Y-m-d');

$firm_no = $data ->col1;
$person_name = $data  ->col2 ;
$person_phone = $data ->col3;

$insert_tend = $database ->prepare ("insert into values_tb(device_id,value1,value2,value3,daten,timen) values ('$firm_no','$person_name','$person_phone','$datenaw', $timenaw );");
$insert_tend -> execute();
$database = null;

?>